#include <vector>
#include "card.h"
#include <string>
#include <stdio.h>
#include <iostream>
#include "deck.h"

using namespace std;
using std::vector;

Deck::Deck(int cards)
{
    for(int i=0; i<cards; i++){
        Card newCard;
        _deck.push_back(newCard);
    }
}

Card Deck::deal() throw(Deck_empty){
    Card card=_deck[_deck.size()];
    _deck.pop_back();
    return card;
}


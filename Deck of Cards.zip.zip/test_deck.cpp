#include <stdlib.h>
#include <stdio.h>
#include "deck.h"
#include "card.h"
#include <string>
#include <vector>

using namespace std;

int main3(){
    Deck deck;
    for(int i=0; i<10; i++){
        Card newCard;
        newCard=deck.deal();
    }

    Deck newDeck(20);
    for(int i=0; i<10; i++){
        Card newCard;
        newCard=deck.deal();
    }
    cout<<"I am here"<<"\n";

    Deck deckFailure;
    for(int i=0; i<15; i++){
        Card newCard;
        try{
            newCard=deck.deal();
        }
        catch(char *c){
            cout<<c;
        }

    }


    return 0;
}

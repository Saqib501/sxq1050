#include "card.h"
#include <iostream>
#include <string>
#include <string.h>
#include <sstream>
#include <stdexcept>

using namespace std;
Card::Card(Suit sut, Rank rnk)
{
    if(rnk<0 || rnk>9)
    {
        try{
            throw runtime_error("\nRank: Out of Range");
        }
        catch(const std::runtime_error& error)
        {
            std::cout<<error.what() <<'\n';
        }
    }
    else if(sut!=Card::U && sut!=Card::T&&sut!=Card::A)
    {
        try{
            throw runtime_error("\nSuit: Out of Range");
        }
        catch(const std::runtime_error& error)
        {
            std::cout<<error.what() <<'\n';
        }
    }
    else
    {
        suit=sut;
        ran=rnk;
    }
}

Card::Card()
{
    ran=(rand()%11)-1;
    int suit_holder=rand()%4;
    if(suit_holder==1){
        suit=U;
    }
    else if(suit_holder==2){
        suit=T;
    }
    else if(suit_holder==3){
        suit=A;
    }
}

Card::~Card()
{

}

Card:: Suit Card::getSuit()
{
    return suit;
}

Card:: Rank Card::getRank()
{
    return ran;
}

string Card::card_to_string()
{
    string suit_string;
    if(suit==U){
        suit_string="U";
    }
    else if(suit==T){
        suit_string="T";
    }
    else if(suit==A){
        suit_string="A";
    }

    string ranke;
    ostringstream convert;
    convert<<ran;
    ranke=convert.str();

    //string ranke=ststic_cast<ostringstream*>( &ostringstream() << ran) ) -> str();

    suit_string.append(ranke);

    return suit_string;
}


#ifndef CARD
#define CARD

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <sstream>
#include <iostream>

using namespace std;


class Card
{
private:
    enum Suit {U, T, A};
    typedef int Rank;

    Suit suit;
    Rank ran;

public:
    Card(Suit, Rank);

    Card();

    ~Card();

    Suit getSuit();

    Rank getRank();

    string card_to_string();

    friend int main();
    friend int main2();
};

#endif

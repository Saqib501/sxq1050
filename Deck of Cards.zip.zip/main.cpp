#include <stdlib.h>
#include <stdio.h>
#include "card.h"
#include <string>

using namespace std;

int main(){
    for(int i=0; i<20; i++){
        Card newCard;
        cout << newCard.card_to_string() << "\t";
    }

    Card newerCard(Card::U, 3);

    Card invalidSuit((Card::Suit)5, 5);

    Card invalidRank(Card::U, 20);
    return 0;
}

#ifndef DECK
#define DECK

#include "card.h"
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <vector>
#include <iostream>

using namespace std;

class Deck{
private:
    std::vector<Card> _deck;
public:
    Deck(int=10);

    class Deck_empty:public exception{
        virtual const char* what() const throw(){
            return "Vector is empty";
        }
        //virtual const char* what() const _GLIBCXX_USE_NOEXCEPT
        //{
        //    return "Vector is empty";
        //}
    };

    Card deal() throw(Deck_empty);


};

#endif
